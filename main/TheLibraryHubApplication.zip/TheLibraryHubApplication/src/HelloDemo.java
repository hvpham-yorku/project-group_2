import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HelloDemo extends JFrame{
    public JPanel panelMain;
    private JLabel Test;
    private JTextField textName;
    private JButton btnClick;

    public HelloDemo() {
        btnClick.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(btnClick,textName.getText()+"Hello I'm amazing.");
            }
        });
    }

    public static void main(String[] args) {
        HelloDemo h =  new HelloDemo();
        h.setContentPane(h.panelMain);
        h.setTitle("BABOYEE");
        h.setSize(150,200);
        h.setVisible(true);
        h.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
